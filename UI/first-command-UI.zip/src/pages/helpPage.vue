<template>
  <q-page>
    <div style="padding-left: 20px;">
      <h3 style="color: #05528c;padding-top:0px;">Introduction</h3>
      <p>Globe Life Inc. has developed FirstCommand Portal exclusively for First Command Financial Planning and it is now available for Field and select Home Office employees. Based on a survey conducted by Globe Life Inc., FirstCommand Portal should answer 85% of the questions routinely asked by Field personnel and Home Office employees. Of course, Globe Life representatives will still be available to answer less common questions. However, your first source of information about in force policies serviced by Globe Life Inc. should be "FirstCommand Portal".</p>
      <p>Information on pending policies is not yet available, but the <b>Contact Us</b> screen can be used for questions about pending policies as well as in force ones. Underwriting questions will be forwarded to underwriters in Birmingham, AL.</p>
      <p>You can access policy information on the following Globe Life serviced insurance companies:</p>
      <ul>
          <li>First United American (FA)</li>
          <li>Globe Life (GL)</li>
          <li>Liberty National (LN)</li>
          <li>Security Benefit (SB)</li>
      </ul>
     </div>
  </q-page>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  // name: 'PageName'
})
</script>
