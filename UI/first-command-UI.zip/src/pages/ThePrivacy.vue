<template>
  <q-page >
    <div class="heads-margin" style=" padding-left: 20px;">
      <h3 style="color: #05528c;padding-top:0px;">Privacy Policy</h3>
      <p>Globe Life Inc. cares about protecting its policyholders' privacy. In the process of providing the products and
         services you requested, we will collect, use and share certain information you provided. This Privacy Policy
         explains what information we collect and how we use that information. The policy also explains how we protect the
         security and confidentiality of your information. </p>
      <h6>Collection of Information</h6>
      <p>We collect and retain the information necessary for us to provide the products and services you requested. In that
         process we may collect non-public information from you as a result of your completion of an insurance application
         or other forms: your transactions and experience with us; or from a consumer reporting agency such as the Medical
         Information Bureau. </p>
      <h6>Confidentiality of Information</h6>
      <p>We do not disclose any non-public information about you, either during or after your relationship with us, to
         anyone, except as permitted by law, such as to your authorized representative, or in order to provide the products
         and services you requested, or to comply with applicable laws or regulations. </p>
      <h6>Internal Protection of Information</h6>
      <p>We restrict access to non-public personal information about you to those employees who need to know that
         information to provide the products and services you requested. We maintain physical, electronic and procedural
         safeguards to comply with federal regulations to guard this information.</p>
      <h6>Disclosure of Our Privacy Policy</h6>
      <p>This notice is posted for informational purposes. We may amend this Privacy Policy at any time and will update it
         as required. We post our current privacy notice at investors.globelifeinsurance.com/privacy-policy</p>
      <!-- <nav class="navbar navbar-light bg-light">
         <a class="navbar-brand mb-0 h1">HELP | CONTACT US | TERMS AND CONDITIONS</a>
      </nav> -->
   </div>
  </q-page>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  // name: 'PageName'
})
</script>
