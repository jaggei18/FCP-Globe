<template>
  <q-page padding>
   <div class="heads-margin" style="padding-left: 20px;">
        <p style="padding-top:0px;"><b>IMPORTANT:</b> Please read the terms and conditions set forth below carefully
            before using this site or any of the programs, content or material available through this site. Use of this site
            is expressly conditioned on your acceptance of the following terms and conditions. By using this site or any of
            the programs, content or material available through the site, you signify your assent to and acceptance of these
            terms and conditions. If you do not agree with any part of the terms and conditions set forth below, you must
            not use this site or any portion thereof. </p>
        <h6 style="color: #05528c;">Who We Are</h6>
        <p>The FirstCommand Portal site ("Site"), is owned and operated by Globe Life Inc. ("Globe Life").</p>
        <h6 style="color: #05528c;">Services Offered Through FirstCommand Portal</h6>
        <p>Our Site is designed to provide FirstCommand employees and agents information on the Globe Life life insurance
            policies that they service.
            The services available on this Site are designed to be completed upon the User providing required information,
            unless otherwise specified.</p>
        <h6 style="color: #05528c;">Customer Complaints</h6>
        <p>Users who have complaints regarding the Site may address such concerns in writing, via e-mail or traditional mail
            to the contact listed below.
            Users may also call 1-972-529-5085 between the hours of 8 AM and 4:30 PM Central Standard Time. </p>
        <h6 style="color: #05528c;">Dispute Resolution</h6>
        <p>Users agree to have any unresolved claim or dispute against Globe Life or its affiliates resolved through
            arbitration as set forth below after first submitting the claim or dispute to mandatory non-binding mediation.
            The User agrees to attempt to resolve any claim or dispute through non-binding mediation before a mediator
            mutually agreeable to the parties and that the forum for any mediation hearing will be Dallas, Texas. The
            parties will each bear their respective costs of mediation.
            If a claim or dispute is not resolved as a result of mediation, the User agrees to have any unresolved claim or
            dispute against Globe Life or its affiliates whether related to this agreement or otherwise, and any claim or
            dispute related to this agreement or the relationship or duties contemplated under this agreement, including the
            validity of this arbitration clause, resolved by binding arbitration by the National Arbitration Forum, under
            the Code of Procedure then in effect. The User agrees that the forum for any such arbitration proceeding shall
            be held in Dallas, Texas. Any award of the arbitrator(s) may be entered as a judgment in any court of competent
            jurisdiction. Information may be obtained and claims may be filed at any office of the National Arbitration
            Forum or at RO. Box 50191, Minneapolis, MN 55405. This agreement shall be interpreted under the Federal
            Arbitration Act.
            Please note that disputes regarding Globe Life or its affiliates may need to be resolved through the National
            Association of Securities Dealers in accordance with their arbitration procedures.</p>
        <h6 style="color: #05528c;">Ownership</h6>
        <p>The Site, each of its components, and the content, programs and materials provided thereby, are the copyrighted
            property of Globe Life, the appropriate Globe Life affiliate or its affiliated entities. None of the content,
            programs, materials or data found on the Site may be modified, reproduced, republished, distributed, sold, or
            transferred without the express written consent of Globe Life, the appropriate Globe Life affiliate or the
            applicable third-party provider. The trademarks and service marks ("Marks") displayed on this Site are the
            property of Globe Life unless specifically indicated otherwise. Users are prohibited from using any Mark without
            the prior written consent of Globe Life or the Globe Life affiliate owning the mark. Nothing contained on this
            Site is intended or should be construed to grant by implication, estoppel, or otherwise, any license to use any
            of the Marks without the express written consent of Globe Life or the Globe Life affiliate owning the mark.</p>
        <h6 style="color: #05528c;">Use</h6>
        <p>This Site, each of its components, and the content, programs, materials and information on the Site are intended
            for your personal use. You are prohibited from using them for commercial purposes without our prior written
            consent. This Site, and the content provided on this Site, may not be copied, reproduced, republished, uploaded,
            posted, transmitted or distributed without the prior written consent of Globe Life. Unauthorized use of this
            Site or the materials contained on this Site may violate applicable intellectual property or other laws. You are
            prohibited from posting on or transmitting to or through the Site any unlawful, threatening, libelous,
            defamatory, obscene, indecent, inflammatory, pornographic or profane material or any material that could
            constitute or encourage conduct that would be considered a criminal offense, give rise to civil liability or
            otherwise violate any law. </p>
        <h6 style="color: #05528c;">Privacy</h6>
        <p>Please see our Privacy Statement regarding our collection, retention and use of information.</p>
        <h6 style="color: #05528c;">Age and Responsibility</h6>
        <p>You represent that you are of legal age and competency to use this Site and to create binding legal obligations
            for any liability you incur as a result of using this Site. You understand and acknowledge that you are
            financially and otherwise responsible for any use of this Site by you and anyone using your login information.
        </p>
        <h6 style="color: #05528c;">Investment and Insurance Information</h6>
        <p>Information available through this site is not intended to be used as the sole basis for any investment or
            insurance decision, nor should it be construed as advice designed to meet the particular needs of an individual
            purchaser of insurance. Please seek the advice of a financial or other professional, as appropriate, regarding
            the evaluation of any specific information, opinion, advice, or other content.</p>
        <h6 style="color: #05528c;">Exclusion of Warranty</h6>
        <p>Globe Life, ITS AFFILIATED ENTITIES AND APPLICABLE THIRD-PARTY PROVIDERS MAKE NO WARRANTIES OF ANY KIND REGARDING
            THIS SITE OR THE CONTENT, PROGRAMS OR MATERIAL PROVIDED ON THIS SITE, ALL OF WHICH ARE PROVIDED ON AN "AS IS"
            BASIS. GLOBE LIFE, ITS AFFILIATED ENTITIES AND APPLICABLE THIRD-PARTY PROVIDERS DO NOT WARRANT THE ACCURACY,
            COMPLETENESS, CURRENCY, RELIABILITY OR AVAILABILITY OF ANY OF THE CONTENT, PROGRAMS, MATERIAL OR DATA FOUND ON
            THIS SITE AND SUCH PARTIES EXPRESSLY DISCLAIM ALL WARRANTIES AND CONDITIONS, INCLUDING IMPLIED WARRANTIES AND
            CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT, AND ANY SUCH WARRANTIES OR
            CONDITIONS ARISING BY STATUTE OR OTHERWISE IN LAW OR FROM A COURSE OF DEALING OR USAGE OF TRADE. SOME STATES DO
            NOT ALLOW THE DISCLAIMER OF IMPLIED WARRANTIES, SO THE FOREGOING EXCLUSION AND DISCLAIMER MAY NOT APPLY TO YOU.
        </p>
        <h6 style="color: #05528c;">Limitation of Liability</h6>
        <p>GLOBE LIFE, ITS AFFILIATED ENTITIES, AND THIRD-PARTY PROVIDERS, WILL NOT BE RESPONSIBLE, AND WILL NOT BE LIABLE,
            FOR ANY DAMAGES TO YOUR COMPUTER EQUIPMENT OR OTHER PROPERTY ARISING FROM YOUR USE OF, BROWSING IN OR
            DOWNLOADING OF ANY CONTENT, PROGRAMS, MATERIALS, DATA, TEXT, IMAGES, AUDIO OR VIDEO FROM THE SITE. IN NO EVENT
            WILL GLOBE LIFE, AFFILIATED ENTITIES OR APPLICABLE THIRD-PARTY PROVIDERS BE LIABLE FOR ANY INJURY, LOSS, DAMAGE
            OR CLAIM, OR ANY SPECIAL, EXEMPLARY, PUNITIVE, INDIRECT, INCIDENTAL OR CONSEQUENTIAL DAMAGES OF ANY KIND
            (INCLUDING, BUT NOT LIMITED TO, LOST PROFITS OR SAVINGS), WHETHER BASED IN CONTRACT, TORT, STRICT LIABILITY OR
            OTHERWISE, ARISING FROM OR IN ANY WAY CONNECTED WITH (A) ANY USE OF THIS SITE, OR CONTENT, PROGRAMS OR MATERIALS
            PROVIDED THROUGH THIS SITE. (B) ANY FAILURE, DELAY, OR UNAVAILABILITY (INCLUDING, BUT NOT LIMITED TO THE USE OF
            OR INABILITY TO USE OR ACCESS ANY CONTENT, PROGRAMS, MATERIAL OR DATA PROVIDED ON THE SITE), (C) THE PERFORMANCE
            OR NON-PERFORMANCE OF GLOBE LIFE, ITS AFFILIATED ENTITIES OR APPLICABLE THIRD-PARTY PROVIDERS, EVEN IF SUCH
            PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF DAMAGES TO SUCH PARTIES OR ANY OTHER PARTY, (D) YOUR DISCLOSURE OF
            YOUR PASSWORD TO, OR USE OF YOUR PASSWORD BY, ANY THIRD PARTY, OR (E) ANY ACCESS TO, OR USE OF, YOUR INFORMATION
            BY AN UNAUTHORIZED PERSON OR UNAUTHORIZED PERSONS. SOME STATES DO NOT ALLOW LIMITATION OF LIABILITY, SO THE
            FOREGOING LIMITATION MAY NOT APPLY TO YOU.</p>
        <h6 style="color: #05528c;">Links to Other Sites</h6>
        <p>This Site contains a link to another Web site in the Dispute Resolution section as a convenience to you and not
            as an endorsement by Globe Life, its affiliates or third-party providers of the contents of such Web site. Globe
            Life, its affiliates and third-party providers, in regards to this linked Web site, make no representation or
            warranty and will not be responsible for its content. Any access made to this linked Web site is done at your
            own risk.</p>
        <h6 style="color: #05528c;">Indemnification</h6>
        <p>You will indemnify and hold harmless Globe Life, its affiliated entities, any third-party providers, and their
            respective officers, directors, employees and agents from and against any claim, damages, cause of action or
            demand, including, but not limited to, reasonable legal, accounting and other professional fees, brought by or
            on your behalf or by third parties as a result of your use of the Site, or any content, programs (including, but
            not limited to, the tax calculation program) or materials provided through the Site.</p>
        <h6 style="color: #05528c;">Modification</h6>
        <p>Globe Life may at any time modify these terms and conditions in whole or in part and your continued use of the
            Site, or any content, programs or materials provided through the Site, will be subject in all respects to the
            terms and conditions in force at the time of such use.</p>
        <h6 style="color: #05528c;">Assignment</h6>
        <p>You may not assign, convey, subcontract or delegate your rights, duties or obligations hereunder. Globe Life may,
            at any time, assign, convey, transfer, delegate or subcontract any or all of its rights or obligations without
            prior notice.</p>
    </div>
  </q-page>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  // name: 'PageName'
})
</script>
