import axios from 'axios'

export default axios.create({
  baseURL: 'https://wiarptoo47.execute-api.us-east-1.amazonaws.com/Prod/'
})
